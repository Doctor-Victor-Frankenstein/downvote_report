from setuptools import setup

setup(
     name='Steem Downvote Report',    
     version='0.7',
     scripts=['downvote_report.py']
     )
