Steem Downvote Report Beem Python Tool by @anthonyadavisii

1. Gets all incoming downvotes on account.
2. Gets all outgoing downvotes from account.
3. Downvote Rank Table Generator: Accepts output from #1 or #2
    to get list of user downvote stats, ranks, and corresponding image.

