from setuptools import setup

setup(
     name='Steem Downvote Report',    
     version='0.3',
     scripts=['downvote_report']
     )
