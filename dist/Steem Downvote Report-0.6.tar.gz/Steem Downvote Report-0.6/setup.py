from setuptools import setup

setup(
     name='Steem Downvote Report',    
     version='0.6',
     scripts=['downvote_report.py']
     )
